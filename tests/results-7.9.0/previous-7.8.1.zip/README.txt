PracticeSuite run package / mab
Import this ZIP in Replay > Import package. Keep the package intact.
Input/camera data is available only for recordings made with 7.2.0 or later.
SHA256SUMS.txt verifies consistency, not origin or physical keyboard input.
ABORTED is an outcome; local validity is a separate observation.
Optional .isaudio contains the recorded game mix and is bound to the input recording. New input formats include observed animation states and real game probes; missing historical channels are labelled.
